#ifndef MINIARRAYSTACK_H
#define MINIARRAYSTACK_H
#include <iostream>     // For cout
#include "RuntimeException.h"
using namespace std;


template <class DataType>
 class miniArrayStack{
private:
enum {DEF_CAPACITY =100}; 	//default stack capacity
DataType* arr;	// The array of items
int	capacity;	// The capacity of the current array
int	top;	// The location of the top element
int stackSize;  //number of elements in stack
 

 public:
 miniArrayStack (int cap= DEF_CAPACITY);	// Constructor for ArrStack
miniArrayStack(const miniArrayStack<DataType> &); 	// Copy contstructor
~miniArrayStack();	// Destructor
int  size()  const;	// get the number of elements in the stack
bool isEmpty() const;	// Check if the stack is empty
const DataType& getTop() const; //throw(StackEmpty);       //get the top emement without popping it
void push(const DataType&); //throw(StackFull);	// Pushes  an  object  onto  the  stack
void pop() ;//throw(StackEmpty);	// Pop an object off the stack 
 void  printStack()  const;	// Prints the stack from the top, down
miniArrayStack<DataType>& operator=(const  miniArrayStack<DataType>&);  //  Assignment  operator
};

//implementations go below...
template<class DataType>
miniArrayStack<DataType>::miniArrayStack(int cap)
{
    capacity = cap;
    arr = new DataType[capacity];
    top = -1;
    stackSize = 0;
}

template<class DataType>
miniArrayStack<DataType>::miniArrayStack(const miniArrayStack<DataType> & rhs)
{
    capacity = rhs.capacity;
    arr = new DataType[capacity];
    top = rhs.top;
    stackSize = rhs.stackSize;
    for(int i = 0; i < top; i++)
        arr[i] = rhs.arr[i];
}
template<class DataType>
miniArrayStack<DataType>::~miniArrayStack()
{
    delete[] arr;
    //cout << "MiniArrayStack Deconstructed" << endl;
}
template<class DataType>
int miniArrayStack<DataType>::size() const
{
    return stackSize;
}
template<class DataType>
bool miniArrayStack<DataType>::isEmpty() const
{
    if(size() == 0)
        return true;
    return false;
}
template<class DataType>
const DataType& miniArrayStack<DataType>::getTop() const
{
        if(isEmpty())
            throw StackEmpty("Stack is Empty. Unable to get top");
        else 
            return arr[top];
}
template<class DataType>
void miniArrayStack<DataType>::push(const DataType& x)
{
        if(size() == capacity)
            throw StackFull("Stack is Full. Unable to push");
        else {
        top++;
        stackSize++;
        arr[top] = x;
        }
}
template<class DataType>
void miniArrayStack<DataType>::pop()
{
    try {
        if(isEmpty())
            throw StackEmpty("Stack is Empty. Unable to pop");
        else {
            top--;
            stackSize--;
        }
    }
    catch (const RuntimeException& error) {
        cout << error.getMessage() << endl;
    }
}
template<class DataType>
void miniArrayStack<DataType>::printStack() const
{
    cout << "Print stack: ";
    for(int i = top; i >= 0; i--)
        cout << arr[i] << " ";
    cout << endl;
}
template<class DataType>
miniArrayStack<DataType>& miniArrayStack<DataType>::operator=(const  miniArrayStack<DataType>& rhs)
{
    capacity = rhs.capacity;
    stackSize = rhs.stackSize;
    top = rhs.top;
    DataType * copy = new DataType[capacity];
    for(int i = 0; i < stackSize; i++)
        copy[i] = rhs.arr[i];
    delete[] arr;
    arr = copy;
    return * this;
}
#endif
