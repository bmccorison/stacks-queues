#ifndef MINIDLIST_H
#define MINIDLIST_H
#include <iostream>     // For cout
using namespace std;


template <class DataType> 
class miniDList{
private:
struct   DNode{	// doubly linked list node
  DataType   data;	//  data stored in node   
  DNode*   next;	//  next node in list   
  DNode*   prev;	//  previous node  in list
};

 DNode* header;	// list sentinels
 DNode* trailer;	
public:
miniDList(){                      // constructor
header = new DNode;
trailer  = new DNode;         //have them point to each other
header->next = trailer;
trailer->prev = header;
}	
miniDList(const   miniDList<DataType>&  l);  // Copy constructor
~miniDList();	// Destructor
const DataType& front() const;      // get front element
const DataType& back() const;       // get back element
void   removeFront();	// Remove the front 
void   removeBack();             // Remove the back 
void addFront(const DataType& e);       // Add to the front 
void addBack(const DataType& e);           // Add to the back
int   size()   const;	// Returns the number of elements in list
bool contains(const DataType& e);   // Tests for membership
void  display()  const;	// Prints the elements of list
 miniDList<DataType>& operator=(const miniDList<DataType>& l);   //Overloaded assignment

protected:                          //local utilities
void add(DNode * v, const DataType& e); //insert new node  before  v
void remove(DNode* v);     //remove node v
};

//implementations go below...
template <class DataType> 
miniDList<DataType>::miniDList(const miniDList<DataType>&  l)
{
    header = new DNode;
    trailer  = new DNode;
    if(l.header->next == l.trailer) {
      header->next = trailer;
      trailer->prev = header;
    }
    else {
      DNode * cur = l.header->next;
      DNode * trailPtr = nullptr;
      DNode * newNode = new DNode;
      header->next = newNode;
      newNode->prev = header;
      newNode->data = cur->data;
      while(cur->next != l.trailer) {
        trailPtr = newNode;
        cur = cur->next;
        newNode = new DNode;
        trailPtr->next = newNode;
        newNode-> prev = trailPtr;
        newNode->data = cur->data;
      }
      newNode->next = trailer;
      trailer->prev = newNode;
    }
}
template <class DataType> 
miniDList<DataType>::~miniDList()
{
  if(header->next == trailer) {
    delete header;
    delete trailer;
  }
  else {
    DNode * cur = header;
    DNode * prev = nullptr;
    while(cur->next) {
        prev = cur;
        cur = cur->next;
        delete prev;
    }
    delete cur;
  }
  //cout << "MiniDList Deconstructed" << endl;
}
template <class DataType> 
const DataType& miniDList<DataType>::front() const
{
  if(header->next == trailer) {
    cout << "List Empty. Unable to get front" << endl;
  }
  else
    return header->next->data;
}
template <class DataType> 
const DataType& miniDList<DataType>::back() const
{
  if(trailer->prev == header)
    cout << "List Empty. Unable to get back" << endl;
  else
    return trailer->prev->data;
}
template <class DataType> 
void miniDList<DataType>::removeFront()
{
    DNode * remove = header->next;
    header->next = remove->next;
    header->next->prev = header;
    //cout << "Remove Front:" << remove->data << endl;
    delete remove;
}
template <class DataType> 
void miniDList<DataType>::removeBack()
{
    DNode * remove = trailer->prev;
    trailer->prev = remove->prev;
    trailer->prev->next = trailer;
    //cout << "Remove Back:" << remove->data << endl;
    delete remove;
}
template <class DataType> 
void miniDList<DataType>::addFront(const DataType& e)
{
    DNode * newNode = new DNode;
    newNode->data = e;
    newNode->next = header->next;
    header->next->prev = newNode;
    header->next = newNode;
    newNode->prev = header;
}
template <class DataType> 
void miniDList<DataType>::addBack(const DataType& e)
{
    DNode * newNode = new DNode;
    newNode->data = e;
    newNode->prev = trailer->prev;
    trailer->prev->next = newNode;
    trailer->prev = newNode;
    newNode->next = trailer;
}
template <class DataType> 
int miniDList<DataType>::size() const
{
    int counter = 0;
    if(header->next == trailer) {
      //cout << "Empty List. Returning size 0" << endl;
      return counter;
    }
    DNode * cur = header->next;
    while(cur != trailer) {
      counter++;
      cur = cur->next;
    }
    return counter;
}
template <class DataType> 
bool miniDList<DataType>::contains(const DataType& e)
{
    if(header->next == trailer) {
      cout << "Empty List. Not in list" << endl;
      return false;
    }
    DNode * cur = header->next;
    while(cur != trailer && cur->data != e) {
      cur = cur->next;
    }
    if(cur == trailer) {
      cout << "Not found in list" << endl;
      return false;
    }
    else
      return true;
}
template <class DataType> 
void miniDList<DataType>::display() const
{
    if(header->next == trailer) {
        cout << "Empty List. Not able to print" << endl;
        return;
    }
    
    DNode * cur = header->next;
    cout << "Display: ";
    while(cur != trailer) {
      cout << cur->data << " ";
      cur = cur->next;
    }
    cout << endl;
}
template <class DataType> 
miniDList<DataType>& miniDList<DataType>::operator=(const miniDList<DataType>& l)
{
    miniDList newDList;
    DNode * cur = l.header->next;
    if(cur == l.trailer)
        return * this;
    DNode * trailPtr = nullptr;
    DNode * newNode = new DNode;
    header->next = newNode;
    newNode->prev = header;
    newNode->data = cur->data;
    while(cur->next != l.trailer) {
      trailPtr = newNode;
      cur = cur->next;
      newNode = new DNode;
      trailPtr->next = newNode;
      newNode-> prev = trailPtr;
      newNode->data = cur->data;
    }
    newNode->next = trailer;
    trailer->prev = newNode;
    return * this;
}
template <class DataType> 
void miniDList<DataType>::add(DNode * v, const DataType& e)
{
    if(header->next == trailer) {
      cout << "Empty List. Unable to add before node input v." << endl;
      return;
    }
    DNode * cur = header;
    DNode * newNode = new DNode;
    newNode->data = e;
    while(cur != trailer && cur->next != v) {
      cur = cur->next;
    }
    if(cur == trailer) {
      cout << "V not foudn in list" << endl;
      return;
    }  
    else {
      newNode->prev = cur;
      newNode->next = cur->next;
      cur->next = newNode;
      newNode->next->prev = newNode;
    }
}
template <class DataType> 
void miniDList<DataType>::remove(DNode* v)
{
    if(header->next == trailer) {
      cout << "Empty List. Unable to remove node input v." << endl;
      return;
    }
    DNode * cur = header->next;
    if(cur == v) {
      header->next = cur->next;
      delete cur;
    }
    else {
      while(cur != trailer && cur != v) {
        cur = cur->next;
      }
      if(cur == trailer) {
        cout << "V not found in list" << endl;
        return;
      }
      else {
        cur->next->prev = cur->prev;
        cur->prev->next = cur->next;
        delete cur;
      }
    }
}
#endif
