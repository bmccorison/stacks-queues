#ifndef MINIARRAYQUEUE_H
#define MINIARRAYQUEUE_H
#include <iostream>     // For cout
#include "RuntimeException.h"
using namespace std;
//use modular arithmetic "%" to save array space, like in-class code example
template <class DataType>
 class miniArrayQueue {
    private:
    enum {DEF_CAPACITY =100}; 	//default queue capacity
DataType* arr;		// The array of items
int	capacity;	// The capacity of the current array
int	front;	// The location of the front element
int	rear;	// The location of the rear element
int queueSize;  //number of elements in queue

 public:
miniArrayQueue (int cap=DEF_CAPACITY );	// Constructor 
miniArrayQueue(const miniArrayQueue<DataType> &); // Copy Constructor
~miniArrayQueue();	//   Destructor
int   size()   const;	// get the number of elements in the queue
bool isEmpty() const;	// Check if the queue is empty
void  enqueue(const  DataType& e); //throw(QueueFull), Enqueue element at rear
void  dequeue();     //throw(QueueEmpty), dequeue element at front 
const DataType& getFront() const ;//throw(QueueEmpty), return the front element but not remove
void  printQueue()  const;	// Prints the queue from the front to the rear
 miniArrayQueue<DataType>& operator=(const miniArrayQueue<DataType>&); // Assignment operator
};


//implementations go below...
template<class DataType>
miniArrayQueue<DataType>::miniArrayQueue(int cap)
{
    capacity = cap;
    arr = new DataType[capacity];
    front = 0, rear = -1, queueSize = 0;
}
template<class DataType>
miniArrayQueue<DataType>::miniArrayQueue(const miniArrayQueue<DataType> &rhs)
{
    capacity = rhs.capacity;
    arr = new DataType[capacity];
    front = rhs.front;
    rear = rhs.rear;
    queueSize = rhs.queueSize;
    for(int i = front; i <= rear; i++)
        arr[i] = rhs.arr[i];
}
template<class DataType>
miniArrayQueue<DataType>::~miniArrayQueue()
{
    delete[] arr;
    //cout << "MiniArrayQueue Deconstructed" << endl;
}
template<class DataType>
int miniArrayQueue<DataType>::size() const
{
    return queueSize;
}
template<class DataType>
bool miniArrayQueue<DataType>::isEmpty() const
{
    if(queueSize <= 0 || front > rear)
        return true;
    return false;
}
template<class DataType>
void miniArrayQueue<DataType>::enqueue(const DataType& e)
{
    try {
        if(queueSize == capacity)
            throw QueueFull("Queue is full. Unable to add");

        else {
            rear++;
            queueSize++;
            arr[rear] = e;
        }
    }
    catch (const RuntimeException& error){
        cout << error.getMessage() << endl;
    }
}
template<class DataType>
void miniArrayQueue<DataType>::dequeue()
{
    try {
        if(isEmpty()) {
            throw QueueEmpty("Queue is Empty. Unable to remove from queue.");
        }
        else {
            front++;
            queueSize--;
        }
    }
    catch (const RuntimeException& error){
        cout << error.getMessage() << endl;
    }
}
template<class DataType>
const DataType& miniArrayQueue<DataType>::getFront() const
{
        if(isEmpty())
            throw QueueEmpty("Queue is Empty. Unable to get Front");
        else 
            return arr[front];
}
template<class DataType>
void miniArrayQueue<DataType>::printQueue() const
{
    if(isEmpty()) {
        throw QueueEmpty("Queue is Empty. Unable to print");
    }
    //cout << "Front:" << front << ". Rear:" << rear << ". Size:" << queueSize << "." << endl;
    cout << "Print Queue: ";
    for(int i = front; i <= rear; i++)
        cout << arr[i] << " ";
    cout << endl;
}
template<class DataType>
miniArrayQueue<DataType>& miniArrayQueue<DataType>::operator=(const  miniArrayQueue<DataType>& rhs)
{
    capacity = rhs.capacity;
    queueSize = rhs.queueSize;
    front = rhs.front;
    rear = rhs.rear;
    DataType * copy = new DataType[capacity];
    for(int i = front; i <= rear; i++)
        copy[i] = rhs.arr[i];
    arr = copy;
    delete[] arr;
    return * this;
}
#endif
